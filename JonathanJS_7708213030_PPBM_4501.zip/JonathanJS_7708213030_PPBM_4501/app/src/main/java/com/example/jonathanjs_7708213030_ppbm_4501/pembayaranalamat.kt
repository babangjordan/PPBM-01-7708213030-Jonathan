package com.example.jonathanjs_7708213030_ppbm_4501

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity

class pembayaranalamat : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pembayaranalamat)

        val imageButton10 = findViewById<ImageButton>(R.id.imageButton10)
        imageButton10.setOnClickListener {
            val intent = Intent(this, pembayaran3::class.java)
            startActivity(intent)
        }
    }
}