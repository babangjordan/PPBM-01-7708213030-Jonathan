package com.example.jonathanjs_7708213030_ppbm_4501

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity

class ordersaya : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.myorder)

        val imagebutton15 = findViewById<ImageButton>(R.id.imageButton15)
        imagebutton15.setOnClickListener {
            val intent = Intent(this, home2::class.java)
            startActivity(intent)
        }
    }
}