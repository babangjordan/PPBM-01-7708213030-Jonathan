package com.example.jonathanjs_7708213030_ppbm_4501

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class about : AppCompatActivity() {
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.about)

        }
}